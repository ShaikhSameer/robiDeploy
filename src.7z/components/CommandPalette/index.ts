import CommandPalette from './CommandPalette';

export default CommandPalette;
