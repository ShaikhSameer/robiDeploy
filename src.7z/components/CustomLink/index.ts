import CustomLink from './CustomLink';

export default CustomLink;
