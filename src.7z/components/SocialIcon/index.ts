import SocialIcon from './SocialIcon';

export default SocialIcon;
