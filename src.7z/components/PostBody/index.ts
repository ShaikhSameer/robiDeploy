import PostBody from './PostBody';

export default PostBody;
