export const giscusConfigs = {
  repo: 'Kamigami55/nextjs-tailwind-contentlayer-blog-starter' as `${string}/${string}`,
  repoId: 'R_kgDOH5XSVA',
  category: 'Announcements',
  categoryId: 'DIC_kwDOH5XSVM4CRfr0',
};
