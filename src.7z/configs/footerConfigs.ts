export const footerConfigs = {
//  credit: 'Stark Industries',
  socialLinks: {
    email: 'stark@example.com',
    github:
      'https://github.com/Kamigami55/nextjs-tailwind-contentlayer-blog-starter',
    twitter: 'https://twitter.com/EasonChang_me',
    facebook: 'https://www.facebook.com/eason.blog',
    linkedin: 'https://www.linkedin.com/in/easonchang101',
  },
};
