export const headerConfigs = {
  title: 'FUTUREPEDIA',
  navLinks: [{ href: '/', title: 'home' },{ href: '/favourites', title: 'Favourites' },{ href: '/en/posts/custom-link-demo', title: 'Discover' },{ href: '/submittool', title: 'SubmitTools' },{ href: '/submitnew', title: 'SubmitNews' },{ href: '/Newsletterissue', title: 'Newsletter' },{ href: '/latestaiNews', title: 'AINews' }],
};
